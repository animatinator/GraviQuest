import pygame


class Character(pygame.sprite.Sprite):
    def __init__(self, parent, pos):
        pygame.sprite.Sprite.__init__(self)
        self.parent = parent
        
        self.images = self.LoadImages("chartest.png")
        self.image = self.images[0]

        self.rect = self.image.get_rect()
        self.rect.topleft = pos

        self.velocity = [0.0, 0.0]
        self.maxspeedx = 8
        self.jumpspeed = 23#15
        self.canfall = True
        self.jumptriggered = False
        self.jumping = False

    def LoadImages(self, imagefile):
        rawimg = pygame.image.load(imagefile)
        images = []
        
        for i in range(0, rawimg.get_width() / self.parent.tilesize):
            # Chop off images to the right of the current one
            rect = rawimg.get_rect()
            rect.width = ((rawimg.get_width() / self.parent.tilesize) - i) * self.parent.tilesize
            rect.height = 0
            rect.x = (i+1) * self.parent.tilesize
            image = pygame.transform.chop(rawimg, rect)
            # Chop off images to the left of the current one
            rect = rawimg.get_rect()
            rect.width = i * self.parent.tilesize
            rect.height = 0
            image = pygame.transform.chop(image, rect).convert_alpha()
            
            images.append(image)

        return images

    def GetSide(self, block):
        distx = self.rect.centerx - block.rect.centerx
        disty = (self.rect.centery - block.rect.centery) / 2.0

        if distx < 0:
            if disty < 0:
                if (abs(disty) < abs(distx)): return "left"
                elif (abs(distx) < abs(disty)): return "top"
            elif disty > 0:
                if (abs(disty) < abs(distx)): return "left"
                elif (abs(distx) < abs(disty)): return "bottom"
            else: return "left"
        elif distx > 0:
            if disty < 0:
                if (abs(disty) < abs(distx)): return "right"
                elif (abs(distx) < abs(disty)): return "top"
            elif disty > 0:
                if (abs(disty) < abs(distx)): return "right"
                elif (abs(distx) < abs(disty)): return "bottom"
            else: return "right"
        else:
            if disty < 0: return "top"
            elif disty > 0: return "bottom"

    def GetGridPos(self):
        if (self.rect.left % self.parent.tilesize) > (self.rect.right % self.parent.tilesize):  # If the character is more in the right grid box than in the left
            return (self.rect.right / self.parent.tilesize, self.rect.top / self.parent.tilesize)
        else:
            return (self.rect.left / self.parent.tilesize, self.rect.top / self.parent.tilesize)

    def Update(self):
        if self.canfall:
            self.velocity[1] += self.parent.gravity
        else:
            self.velocity[1] = 0
            self.jumping = False

        if pygame.key.get_pressed()[pygame.K_LEFT]:
            if self.velocity[0] > 0 and self.jumping == False:
                self.image = self.images[5]
            else:
                self.image = self.images[1]
            if self.velocity[0] > -self.maxspeedx:
                self.velocity[0] -= 1
            else:
                self.velocity[0] = -self.maxspeedx
                
        elif pygame.key.get_pressed()[pygame.K_RIGHT]:
            if self.velocity[0] < 0 and self.jumping == False:
                self.image = self.images[4]
            else:
                self.image = self.images[2]
            if self.velocity[0] < self.maxspeedx:
                self.velocity[0] += 1
            else:
                self.velocity[0] = self.maxspeedx

        else:
            if self.velocity[0] < 0 and self.jumping == False:
                self.image = self.images[4]
                self.velocity[0] += 1
            elif self.velocity[0] > 0 and self.jumping == False:
                self.image = self.images[5]
                self.velocity[0] -= 1
            else:
                if self.jumping:
                    self.image = self.images[3]
                else:
                    self.image = self.images[0]

        if self.jumptriggered:
            self.jumptriggered = False
            if not self.jumping:
                self.canfall = True
                self.jumping = True
                self.velocity[1] = -self.jumpspeed

        self.rect.left += self.velocity[0]
        self.rect.top += self.velocity[1]

    def Redraw(self):
        temprect = self.rect.move(0, 0)  # Makes a copy of the position rect
        temprect.left -= self.parent.camerapos[0]
        temprect.top -= self.parent.camerapos[1]
        self.parent.screen.blit(self.image, temprect)
