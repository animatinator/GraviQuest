import pygame, sys, math
from character import *


clock = pygame.time.Clock()

def Distance(a, b):
    return math.sqrt((abs(b[0] - a[0])^2) + (abs(b[1] - a[1])^2))

class FloorBrick(pygame.sprite.Sprite):
    def __init__(self, parent, pos):
        pygame.sprite.Sprite.__init__(self)
        self.parent = parent
        self.image = pygame.image.load("floorbrick.png").convert()
        self.rect = self.image.get_rect()
        self.rect.topleft = pos

    def Redraw(self):
        temprect = self.rect.move(0, 0)  # Makes a copy of the position rect
        temprect.left -= self.parent.camerapos[0]
        temprect.top -= self.parent.camerapos[1]
        self.parent.screen.blit(self.image, temprect)

class Block(pygame.sprite.Sprite):
    def __init__(self, parent, pos):
        pygame.sprite.Sprite.__init__(self)
        self.parent = parent
        self.image = pygame.image.load("block.png").convert()
        self.rect = self.image.get_rect()
        self.rect.topleft = pos

    def Redraw(self):
        temprect = self.rect.move(0, 0)
        temprect.left -= self.parent.camerapos[0]
        temprect.top -= self.parent.camerapos[1]
        self.parent.screen.blit(self.image, temprect)


class Level():
    def __init__(self, screen, datafile):
        self.screen = screen
        self.running = False
        self.returnval = None

        self.camerapos = [0, 0]
        self.maxcamshortdist = 150
        self.maxcamspeeds = [7, 5]  # Short distances (lesser than maxcamshortdist)
        self.maxcamspeedl = [30, 30]  # Long distances (greater than maxcamshortdist)
        self.gravity = 1.5
        self.tilesize = 50

        self.levelgrid = []
        self.floorbricks = pygame.sprite.Group()
        self.blocks = pygame.sprite.Group()
        self.character = pygame.sprite.GroupSingle()
        self.goalpos = (0, 0)
        self.LoadLevel(datafile)

        self.bgimage = pygame.image.load("levelbg.png")

        self.mousepos = [400, 300]

    def LoadLevel(self, datafile):
        rawleveldata = open(datafile, "r").readlines()  # Get the level data as a list of lines
    
        # Split the lines into individual items
        leveldata = []
        for line in rawleveldata:
            leveldata.append(list(line))

        for y, line in enumerate(leveldata):  # For each row
            row = []
            for x, item in enumerate(line):  # For each column in the row
                thistile = [item]  # Items in the grid consist of ["itemtype", <reference to object where possible>]
                if item == "F":  # Floor brick
                    newfloorbrick = FloorBrick(self, (x * self.tilesize, y * self.tilesize))
                    self.floorbricks.add(newfloorbrick)
                    thistile.append(newfloorbrick)
                elif item == "B":  # Block
                    newblock = Block(self, (x * self.tilesize, y * self.tilesize))
                    self.blocks.add(newblock)
                    thistile.append(newblock)
                elif item == "S":  # Character start point
                    character = Character(self, (x * self.tilesize, y * self.tilesize))
                    self.character.add(character)
                    thistile.append(None)
                elif item == "G":  # Goal point
                    self.goalpos = (x * self.tilesize, y * self.tilesize)
                    thistile.append(None)
                else:  # Empty (or at least unimportant) tile
                    thistile = [0, None]

                row.append(thistile)  # Append this tile to the row
            self.levelgrid.append(row)  # Append this row to the grid

    def GetCollisions(self):
        charpos = self.character.sprite.GetGridPos()
        potentials = []  # A list of occupied squares around the character

        for xval in range(-1, 2):  # Test from one left to one right of the character (co-ordinates are relative to the player position here)
            for yval in range(-1, 3):  # Test from one below to one above the character
                # Get the absolute x and y grid co-ordinates for this tile
                x = charpos[0] + xval
                y = charpos[1] + yval
                try:
                    # Append 'F' and 'B' (floor and block) to the list of potential collisions
                    if self.levelgrid[y][x][0] == "F":
                        potentials.append(self.levelgrid[y][x])
                    elif self.levelgrid[y][x][0] == "B":
                        potentials.append(self.levelgrid[y][x])
                except:  # It seems likely that this square is off the grid
                    pass

        collisions = []
        
        for potential in potentials:  # Test for collisions between the character and objects in the potentials list
            if pygame.sprite.collide_rect(self.character.sprite, potential[1]):
                collisions.append(potential)

        return collisions

    def MainLoop(self):
        self.running = True
        
        while self.running:
            self.mousepos = pygame.mouse.get_pos()
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        self.returnval = "quit"
                        self.running = False

                    elif event.key == pygame.K_UP:
                        self.character.sprite.jumptriggered = True

            self.Update()

            if self.returnval != None:  # If the return value has changed (indicates a win or fail)
                break
            
            self.Redraw()

            clock.tick(30)

        return self.returnval

    def Update(self):
        # Old mouse-based camera control
        #newcamx = self.camerapos[0] + int(float(self.mousepos[0] - (self.screen.get_width() / 2.0)) * 0.1)
        #newcamy = self.camerapos[1] + int(float(self.mousepos[1] - (self.screen.get_height() / 2.0)) * 0.1)
        #self.camerapos = [newcamx, newcamy]

        # Move the camera to keep up with the character (such that it is centre-screen), within speed limits
        camdistx = (self.character.sprite.rect.centerx - self.camerapos[0]) - (self.screen.get_width() / 2)
        camdisty = (self.character.sprite.rect.centery - self.camerapos[1]) - (self.screen.get_height() / 2)

        if camdistx > self.maxcamshortdist:
            if camdistx > self.maxcamspeedl[0]:
                camdistx = self.maxcamspeedl[0]
        else:
            if camdistx > self.maxcamspeeds[0]:
                camdistx = self.maxcamspeeds[0]

        if camdisty > self.maxcamshortdist:
            if camdisty > self.maxcamspeedl[1]:
                camdisty = self.maxcamspeedl[1]
        else:
            if camdisty > self.maxcamspeeds[1]:
                camdisty = self.maxcamspeeds[1]

        self.camerapos = [self.camerapos[0] + camdistx, self.camerapos[1] + camdisty]

        # Update the character
        self.character.sprite.Update()

        # Test for collisions
        collisions = self.GetCollisions()
        
        if collisions:
            for obj in collisions:
                block = obj[1]
                side = self.character.sprite.GetSide(block)

                if side == "top":
                    self.character.sprite.rect.top = block.rect.top - (self.tilesize * 2)
                    self.character.sprite.canfall = False
                    self.character.sprite.jumping = False
                    self.character.sprite.velocity[1] = 0
                elif side == "bottom":
                    self.character.sprite.rect.top = block.rect.top + self.tilesize
                    self.character.sprite.velocity[1] = 0
                elif side == "left":
                    self.character.sprite.rect.left = block.rect.left - self.tilesize
                    self.character.sprite.velocity[0] = 0
                elif side == "right":
                    self.character.sprite.rect.left = block.rect.left + self.tilesize
                    self.character.sprite.velocity[0] = 0
                else:
                    print "FAIL"

        chargridpos = self.character.sprite.GetGridPos()
        canfall = True
        try:
            if self.levelgrid[chargridpos[1] + 2][chargridpos[0]][0] != 0:
                canfall = False
        except:  # The grid position perhaps doesn't exist - assume it is empty
            canfall = True
        if chargridpos[0] < 0:  # Prevents strange errors when the character is offscreen - it should ALWAYS fall, as the offscreen area is empty
            canfall = True
        self.character.sprite.canfall = canfall

        if self.character.sprite.rect.top > 1200:
            self.returnval = "fail"

        if Distance(self.character.sprite.rect.topleft, self.goalpos) < 5:
            self.returnval = "win"

    def Redraw(self):
        self.screen.blit(self.bgimage, (0, 0))
        
        #for i in range(0, self.screen.get_height()):
        #    colour = 255.0 * (float(i) / 600.0)
        #    pygame.draw.line(self.screen, (colour, colour, colour), (0, i), (800, i))

        # Draw floor bricks
        for floorbrick in self.floorbricks.sprites():
            floorbrick.Redraw()

        # Draw blocks
        for block in self.blocks.sprites():
            block.Redraw()

        # Draw character
        self.character.sprite.Redraw()
        
        pygame.display.update()
