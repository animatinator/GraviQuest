import pygame, sys, math
from character import *


clock = pygame.time.Clock()

def Distance(a, b):
    return math.sqrt((abs(b[0] - a[0])^2) + (abs(b[1] - a[1])^2))

class FloorBrick(pygame.sprite.Sprite):
    def __init__(self, parent, pos):
        pygame.sprite.Sprite.__init__(self)
        self.parent = parent
        self.image = pygame.image.load("floorbrick.png")
        self.rect = self.image.get_rect()
        self.rect.topleft = pos

    def Redraw(self):
        temprect = self.rect.move(0, 0)  # Makes a copy of the position rect
        temprect.left -= self.parent.camerapos[0]
        temprect.top -= self.parent.camerapos[1]
        self.parent.screen.blit(self.image, temprect)

class Block(pygame.sprite.Sprite):
    def __init__(self, parent, pos):
        pygame.sprite.Sprite.__init__(self)
        self.parent = parent
        self.image = pygame.image.load("block.png")
        self.rect = self.image.get_rect()
        self.rect.topleft = pos

    def Redraw(self):
        temprect = self.rect.move(0, 0)
        temprect.left -= self.parent.camerapos[0]
        temprect.top -= self.parent.camerapos[1]
        self.parent.screen.blit(self.image, temprect)


class Level():
    def __init__(self, screen, datafile):
        self.screen = screen
        self.running = False
        self.returnval = None

        self.camerapos = [0, 0]
        self.gravity = 1.5

        self.levelgrid = []
        self.floorbricks = pygame.sprite.Group()
        self.blocks = pygame.sprite.Group()
        self.character = pygame.sprite.GroupSingle()
        self.goalpos = (0, 0)
        self.LoadLevel(datafile)

        self.bgimage = pygame.image.load("levelbg.png")

        self.mousepos = [400, 300]

    def LoadLevel(self, datafile):
        rawleveldata = open(datafile, "r").readlines()
    
        # Split the lines into individual items
        leveldata = []
        
        for line in rawleveldata:
            leveldata.append(list(line))

        for y, line in enumerate(leveldata):
            row = []
            for x, item in enumerate(line):
                thistile = item
                if item == "F":
                    newfloorbrick = FloorBrick(self, (x * 25, y * 25))
                    self.floorbricks.add(newfloorbrick)
                elif item == "B":
                    newblock = Block(self, (x * 25, y * 25))
                    self.blocks.add(newblock)
                elif item == "S":
                    character = Character(self, (x * 25, y * 25))
                    self.character.add(character)
                elif item == "G":
                    self.goalpos = (x * 25, y * 25)
                else:
                    thistile = 0

                row.append(thistile)
            self.levelgrid.append(row)

    def MainLoop(self):
        self.running = True
        
        while self.running:
            self.mousepos = pygame.mouse.get_pos()
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        self.returnval = "quit"
                        self.running = False

                    elif event.key == pygame.K_UP:
                        self.character.sprite.jumptriggered = True

            self.Update()

            if self.returnval != None:  # If the return value has changed (indicates a win or fail)
                break
            
            self.Redraw()

            clock.tick(30)

        return self.returnval

    def Update(self):
        #newcamx = self.camerapos[0] + int(float(self.mousepos[0] - (self.screen.get_width() / 2.0)) * 0.1)
        #newcamy = self.camerapos[1] + int(float(self.mousepos[1] - (self.screen.get_height() / 2.0)) * 0.1)
        #self.camerapos = [newcamx, newcamy]

        self.character.sprite.Update()
        collisions = pygame.sprite.spritecollide(self.character.sprite, self.floorbricks, False, pygame.sprite.collide_rect)
        collisions.extend(pygame.sprite.spritecollide(self.character.sprite, self.blocks, False, pygame.sprite.collide_rect))
        if collisions:            
            for block in collisions:
                side = self.character.sprite.GetSide(block)

                if side == "top":
                    self.character.sprite.rect.top = block.rect.top - 50
                    self.character.sprite.canfall = False
                    self.character.sprite.jumping = False
                    self.character.sprite.velocity[1] = 0
                elif side == "bottom":
                    self.character.sprite.rect.top = block.rect.top + 25
                    self.character.sprite.velocity[1] = 0
                elif side == "left":
                    self.character.sprite.rect.left = block.rect.left - 25
                    self.character.sprite.velocity[0] = 0
                elif side == "right":
                    self.character.sprite.rect.left = block.rect.left + 25
                    self.character.sprite.velocity[0] = 0
                else:
                    print "FAIL"

        chargridpos = self.character.sprite.GetGridPos()
        canfall = True
        if self.levelgrid[chargridpos[1] + 2][chargridpos[0]] != 0:
            canfall = False
        self.character.sprite.canfall = canfall

        if self.character.sprite.rect.top > 600:
            self.returnval = "fail"

        if Distance(self.character.sprite.rect.topleft, self.goalpos) < 5:
            self.returnval = "win"

    def Redraw(self):
        self.screen.blit(self.bgimage, (0, 0))
        
        #for i in range(0, self.screen.get_height()):
        #    colour = 255.0 * (float(i) / 600.0)
        #    pygame.draw.line(self.screen, (colour, colour, colour), (0, i), (800, i))

        # Draw floor bricks
        for floorbrick in self.floorbricks.sprites():
            floorbrick.Redraw()

        # Draw blocks
        for block in self.blocks.sprites():
            block.Redraw()

        # Draw character
        self.character.sprite.Redraw()
        
        pygame.display.update()
