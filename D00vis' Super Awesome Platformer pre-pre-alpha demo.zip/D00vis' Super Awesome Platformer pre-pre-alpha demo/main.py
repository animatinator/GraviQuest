import pygame, sys
from spinmenu import *
from level import *

pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("D00vis' funky WIP game thingy")

def PlayLevel():
    level = Level(screen, "test.lvl")
    returnval = level.MainLoop()

    if returnval == "quit":
        ShowMenu()
    elif returnval == "fail":
        PlayLevel()
    elif returnval == "win":
        return

def ShowMenu():
    mainmenu = Menu(screen,
        [["New game", "new"], ["Load game", "load"], ["Instructions", "instruct"], ["Quit", "quit"]],
        (400, 300), 200, 100, (100, 255, 50), (75, 150, 50), "Menubg.png")
    selection = mainmenu.ShowMenu()

    if selection == "new":
        PlayLevel()
    elif selection == "load":
        pass
    elif selection == "instruct":
        pass
    elif selection == "quit":
        sys.exit()

while 1:
    ShowMenu()
