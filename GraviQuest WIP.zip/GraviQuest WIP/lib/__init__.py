from spinmenu import *
from level import *
from credits import *
from intro import *
from tutorial import *
from infobox import *
