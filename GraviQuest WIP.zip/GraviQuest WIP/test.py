#from lib import *
import pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
from lib import *
showTitle(screen, "Testing", 50)