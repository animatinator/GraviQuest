import pygame, sys, math
from character import *


# Gravity directions
DOWN = 0
LEFT = 1
UP = 2
RIGHT = 3

clock = pygame.time.Clock()

def Distance(a, b):
    return math.sqrt((abs(b[0] - a[0])^2) + (abs(b[1] - a[1])^2))

class FloorBrick(pygame.sprite.Sprite):
    def __init__(self, parent, pos):
        pygame.sprite.Sprite.__init__(self)
        self.parent = parent
        self.image = pygame.image.load("floorbrick.png").convert()
        self.rect = self.image.get_rect()
        self.rect.topleft = pos
        self.onscreenbefore = False

    def Redraw(self):
        if self.onscreenbefore:
            self.parent.dirtyrects.append(self.oldabsrect)
        
        absrect = self.rect.move(0, 0)  # Makes a copy of the position rect
        absrect.left -= self.parent.camerapos[0]
        absrect.top -= self.parent.camerapos[1]

        if (absrect.left < self.parent.screen.get_width() and absrect.right > 0) and (absrect.top < self.parent.screen.get_height() and absrect.bottom > 0):
            self.onscreenbefore = True            
            self.parent.screen.blit(self.image, absrect)
            self.parent.dirtyrects.append(absrect)
            self.oldabsrect = absrect

class SpinBlock(pygame.sprite.Sprite):
    def __init__(self, parent, pos, spintype):
        pygame.sprite.Sprite.__init__(self)
        self.parent = parent
        self.spintype = spintype
        self.image = pygame.image.load("block.png").convert()
        self.rect = self.image.get_rect()
        self.rect.topleft = pos
        self.onscreenbefore = False

    def Redraw(self):
        if self.onscreenbefore:
            self.parent.dirtyrects.append(self.oldabsrect)
        
        absrect = self.rect.move(0, 0)  # Makes a copy of the position rect
        absrect.left -= self.parent.camerapos[0]
        absrect.top -= self.parent.camerapos[1]

        if (absrect.left < self.parent.screen.get_width() and absrect.right > 0) and (absrect.top < self.parent.screen.get_height() and absrect.bottom > 0):
            self.onscreenbefore = True            
            self.parent.screen.blit(self.image, absrect)
            self.parent.dirtyrects.append(absrect)
            self.oldabsrect = absrect


class Level():
    def __init__(self, screen, datafile):
        self.screen = screen
        self.running = False
        self.returnval = None

        self.camerapos = [500, 0]
        self.maxcamshortdist = 250
        self.maxcamspeeds = [7, 5]  # Short distances (lesser than maxcamshortdist)
        self.maxcamspeedl = [30, 30]  # Long distances (greater than maxcamshortdist)
        self.gravity = 1.5
        self.gravitydir = DOWN
        
        self.tilesize = 50

        self.levelgrid = []
        self.floorbricks = pygame.sprite.Group()
        self.blocks = pygame.sprite.Group()
        self.character = pygame.sprite.GroupSingle()
        self.goalpos = (0, 0)
        self.LoadLevel(datafile)
        
        self.goalimg = pygame.image.load("goal.png").convert_alpha()
        self.oldgoalrect = None

        self.bgimage = pygame.image.load("levelbg.png")
        self.dirtyrects = []
        self.needsdrawn = True

        self.mousepos = [400, 300]

    def LoadLevel(self, datafile):
        rawleveldata = open(datafile, "r").readlines()  # Get the level data as a list of lines
    
        # Split the lines into individual items
        leveldata = []
        for line in rawleveldata:
            leveldata.append(list(line))

        for y, line in enumerate(leveldata):  # For each row
            row = []
            for x, item in enumerate(line):  # For each column in the row
                thistile = [item]  # Items in the grid consist of ["itemtype", <reference to object where possible>]
                if item == "F":  # Floor brick
                    newfloorbrick = FloorBrick(self, (x * self.tilesize, y * self.tilesize))
                    self.floorbricks.add(newfloorbrick)
                    thistile.append(newfloorbrick)
                elif item == "L":  # Left spinblock
                    newblock = SpinBlock(self, (x * self.tilesize, y * self.tilesize), "left")
                    self.blocks.add(newblock)
                    thistile.append(newblock)
                elif item == "R":  # Right spinblock
                    newblock = SpinBlock(self, (x * self.tilesize, y * self.tilesize), "right")
                    self.blocks.add(newblock)
                    thistile.append(newblock)
                elif item == "S":  # Character start point
                    character = Character(self, (x * self.tilesize, y * self.tilesize))
                    self.character.add(character)
                    thistile.append(None)
                elif item == "G":  # Goal point
                    self.goalpos = (x * self.tilesize, y * self.tilesize)
                    thistile.append(None)
                else:  # Empty (or at least unimportant) tile
                    thistile = [0, None]

                row.append(thistile)  # Append this tile to the row
            self.levelgrid.append(row)  # Append this row to the grid

    def GetCollisions(self):
        charpos = self.character.sprite.GetGridPos()
        potentials = []  # A list of occupied squares around the character

        if self.gravitydir == DOWN or self.gravitydir == UP:
            minx = -1
            maxx = 2
            miny = -1
            maxy = 3
        else:
            minx = -1
            maxx = 3
            miny = -1
            maxy = 2

        for xval in range(minx, maxx):  # Test from one left to one right of the character (co-ordinates are relative to the player position here)
            for yval in range(miny, maxy):  # Test from one below to one above the character
                # Get the absolute x and y grid co-ordinates for this tile
                x = charpos[0] + xval
                y = charpos[1] + yval
                try:
                    # Append 'F', 'L' and 'R' (floor and spinblocks) to the list of potential collisions
                    gridval = self.levelgrid[y][x][0]
                    if gridval == "F" or gridval == "L" or gridval == "R":
                        potentials.append(self.levelgrid[y][x])
                except:  # It seems likely that this square is off the grid
                    pass

        collisions = []
        
        for potential in potentials:  # Test for collisions between the character and objects in the potentials list
            if pygame.sprite.collide_rect(self.character.sprite, potential[1]):
                collisions.append(potential)

        return collisions

    def Rotate(self, direction):
        if direction == "right":
            if self.gravitydir < RIGHT:
                self.gravitydir += 1
            else:
                self.gravitydir = DOWN

        elif direction == "left":
            if self.gravitydir > DOWN:
                self.gravitydir -= 1
            else:
                self.gravitydir = RIGHT

        self.character.sprite.Rotate(direction)
                
    def MainLoop(self):
        self.running = True
        
        while self.running:
            self.mousepos = pygame.mouse.get_pos()
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        self.returnval = "quit"
                        self.running = False

                    elif event.key == pygame.K_UP:
                        self.character.sprite.jumptriggered = True

            self.Update()

            if self.returnval != None:  # If the return value has changed (indicates a win or fail)
                break
            
            self.Redraw()

            clock.tick(30)

        return self.returnval

    def Update(self):
        # Old mouse-based camera control
        #newcamx = self.camerapos[0] + int(float(self.mousepos[0] - (self.screen.get_width() / 2.0)) * 0.1)
        #newcamy = self.camerapos[1] + int(float(self.mousepos[1] - (self.screen.get_height() / 2.0)) * 0.1)
        #self.camerapos = [newcamx, newcamy]

        # Move the camera to keep up with the character (such that it is centre-screen), within speed limits
        camdistx = (self.character.sprite.rect.centerx - self.camerapos[0]) - (self.screen.get_width() / 2)
        camdisty = (self.character.sprite.rect.centery - self.camerapos[1]) - (self.screen.get_height() / 2)

        if abs(camdistx) > self.maxcamshortdist:
            if abs(camdistx) > self.maxcamspeedl[0]:
                camdistx = (camdistx / abs(camdistx)) * self.maxcamspeedl[0]  # Makes sure that the sign (+/-) of the speed matches that of the distance
        else:
            if abs(camdistx) > self.maxcamspeeds[0]:
                camdistx = (camdistx / abs(camdistx)) * self.maxcamspeeds[0]

        if abs(camdisty) > self.maxcamshortdist:
            if abs(camdisty) > self.maxcamspeedl[1]:
                camdisty = (camdisty / abs(camdisty)) * self.maxcamspeedl[1]
        else:
            if abs(camdisty) > self.maxcamspeeds[1]:
                camdisty = (camdisty / abs(camdisty)) * self.maxcamspeeds[1]

        self.camerapos = [self.camerapos[0] + camdistx, self.camerapos[1] + camdisty]

        # Update the character
        self.character.sprite.Update()

        # Test for collisions
        collisions = self.GetCollisions()
        
        if collisions:
            for obj in collisions:
                block = obj[1]
                side = self.character.sprite.GetSide(block)

                if side == "top":
                    self.character.sprite.rect.top = block.rect.top - self.character.sprite.rect.height
                    self.character.sprite.velocity[1] = 0
                elif side == "bottom":
                    self.character.sprite.rect.top = block.rect.top + self.tilesize
                    self.character.sprite.velocity[1] = 0
                elif side == "left":
                    self.character.sprite.rect.left = block.rect.left - self.character.sprite.rect.width
                    self.character.sprite.velocity[0] = 0
                elif side == "right":
                    self.character.sprite.rect.left = block.rect.left + self.tilesize
                    self.character.sprite.velocity[0] = 0
                else:
                    print "FAIL"

                if (side == "top" and self.gravitydir == DOWN) or (side == "bottom" and self.gravitydir == UP) or (side == "left" and self.gravitydir == RIGHT) or (side == "right" and self.gravitydir == LEFT):
                    self.character.sprite.canfall = False
                    self.character.sprite.jumping = False

                # React to the player headbutting spin-blocks
                if obj[0] == "R":  # Right-spin
                    if (side == "top" and self.gravitydir == UP) or (side == "right" and self.gravitydir == RIGHT) or (side == "bottom" and self.gravitydir == DOWN) or (side == "left" and self.gravitydir == LEFT):
                        self.Rotate("right")
                elif obj[0] == "L":  # Left-spin
                    if (side == "top" and self.gravitydir == UP) or (side == "right" and self.gravitydir == RIGHT) or (side == "bottom" and self.gravitydir == DOWN) or (side == "left" and self.gravitydir == LEFT):
                        self.Rotate("left")

        chargridpos = self.character.sprite.GetGridPos()
        canfall = True
        if self.gravitydir == DOWN:
            try:
                if self.levelgrid[chargridpos[1] + 2][chargridpos[0]][0] != 0:
                    canfall = False
            except:  # The grid position perhaps doesn't exist - assume it is empty
                canfall = True
            if chargridpos[0] < 0:  # Prevents strange errors when the character is offscreen - it should ALWAYS fall, as the offscreen area is empty
                canfall = True
        elif self.gravitydir == LEFT:
            try:
                if self.levelgrid[chargridpos[1]][chargridpos[0] - 1][0] != 0:
                    canfall = False
            except:  # The grid position perhaps doesn't exist - assume it is empty
                canfall = True
        elif self.gravitydir == UP:
            try:
                if self.levelgrid[chargridpos[1] - 1][chargridpos[0]][0] != 0:
                    canfall = False
            except:  # The grid position perhaps doesn't exist - assume it is empty
                canfall = True
            if chargridpos[0] < 0:  # Prevents strange errors when the character is offscreen - it should ALWAYS fall, as the offscreen area is empty
                canfall = True
        elif self.gravitydir == RIGHT:
            try:
                if self.levelgrid[chargridpos[1]][chargridpos[0] + 2][0] != 0:
                    canfall = False
            except:  # The grid position perhaps doesn't exist - assume it is empty
                canfall = True
        self.character.sprite.canfall = canfall

        if self.character.sprite.rect.top > 1200:
            self.returnval = "fail"

        if Distance(self.character.sprite.rect.topleft, self.goalpos) < 5:
            self.returnval = "win"

    def Redraw(self):
        self.screen.blit(self.bgimage, (0, 0))
        
        #for i in range(0, self.screen.get_height()):
        #    colour = 255.0 * (float(i) / 600.0)
        #    pygame.draw.line(self.screen, (colour, colour, colour), (0, i), (800, i))

        # Draw floor bricks
        for floorbrick in self.floorbricks.sprites():
            floorbrick.Redraw()

        # Draw blocks
        for block in self.blocks.sprites():
            block.Redraw()

        # Draw the goal
        goalx = self.goalpos[0] - self.camerapos[0]
        goaly = self.goalpos[1] - self.camerapos[1]

        if self.oldgoalrect:
            self.dirtyrects.append(self.oldgoalrect)

        if ((goalx + self.tilesize) > 0 and goalx < self.screen.get_width() and (goaly + (self.tilesize * 2)) > 0 and goaly < self.screen.get_height()):
            self.screen.blit(self.goalimg, (goalx, goaly))
            goalrect = pygame.Rect(goalx, goaly, self.tilesize, self.tilesize * 2)
            self.dirtyrects.append(goalrect)
            self.oldgoalrect = goalrect
        
        # Draw character
        self.character.sprite.Redraw()

        if self.needsdrawn:  # If the level has not been drawn yet:
            pygame.display.update(self.screen.get_rect())
            self.needsdrawn = False
        else:
            pygame.display.update(self.dirtyrects)
        self.dirtyrects = []
