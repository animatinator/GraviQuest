----- GraviQuest - Pre-alpha release 1 -----

-- About
	GraviQuest is a platformer/puzzle game in which the objective in each level is, unsurprisingly, to reach the goal. However, this task is made slightly more complicated by the fact that it will often be necessary to 'rotate' gravity in order to reach said goal.

-- How to play
	To play the game, run 'main.py'. This will start up the main menu, from which you can select either 'New Game' or 'Quit' (the other options just restart the menu at the moment :P ). Not content with just making a normal menu, I decided to make it a nifty spinny thingy - you can scroll through the options by shifting your mouse in the appropriate direction.
	In keeping with tradition, you move your character left and right with the corresponding arrow keys. The up arrow is used to jump, and the 'Q' key quits to the main menu. That's about as complicated as it gets. At the moment, there are two types of blocks - the standard floor block, and the ever-so-mysterious '?' block which rotates gravity. In the final game it'll probably have some sort of spinny icon indicating which direction it turns you in instead of the question mark; the current one is just a quick doodle (like every other graphical entity in the game at the moment). The goal is marked out with an incredibly rubbish-looking door image (which I added in a few minutes ago, realising that people trying my game wouldn't know where I'd put it otherwise).

-- Known bugs
-The character sprite doesn't redraw properly when it spins - it often leaves part of its non-rotated self on the screen
-The camera's a bit glitchy, most noticably when the level starts (it does a sort of staircase-movement towards the character)
-The game runs a bit slowly - any optimisation tips would be most welcome
-You can't jump a second time after jumping, but you can however jump in midair between walking off a ledge and hitting something below it. I actually know perfectly well how to fix this, I just haven't gotten around to it yet.
-Strange things happen when your character goes off the edge of the level. Going off the bottom has the expected effect of failing you and restarting the level, but all the other ones haven't been implemented yet and so the character will either fall indefinitely or stop in midair. Pressing 'Q' is the only way to escape from that terrible fate at the moment.